import pandas
df=pandas.read_csv("nato_phonetic_alphabet.csv")
letters=[row.letter for (index,row) in df.iterrows()]
words=[row.code for (index1,row) in df.iterrows()]
NATO_dict={key:value for key,value in zip(letters,words)}
name=input("Enter the name:  ").upper()
NATO_words=[NATO_dict[a] for a in name]
print(NATO_words)