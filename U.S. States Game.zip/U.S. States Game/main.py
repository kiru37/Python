import turtle
import pandas

screen = turtle.Screen()
pen=turtle.Turtle()

state=pandas.read_csv("50_states.csv")
screen.title("U.S. States Game")
image="blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)

state_list=state.state.to_list()

score=0
total_state=len(state_list)
correct_guess=[]



while len(correct_guess)<total_state:
    answer = screen.textinput(f"{score}/{total_state} State Correct",
                              "What is the state's name?").title()
    current_state = state[state.state == answer]
    if answer == "Exit":
        missing_state=[]
        for state in state_list:
            if state not in correct_guess:
                missing_state.append(state)
        new_data=pandas.DataFrame(missing_state)
        new_data.to_csv("missing_states.csv")
        break
    for ans in state_list:
        if ans==answer:
            correct_guess.append(ans)
            pen.hideturtle()
            pen.penup()
            pen.goto(current_state.x.item(),current_state.y.item())
            pen.write(current_state.state.item())
            score+=1

